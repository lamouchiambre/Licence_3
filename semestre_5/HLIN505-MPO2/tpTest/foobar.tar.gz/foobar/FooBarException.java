package tpTest.foobar;

public class FooBarException extends Exception {

}
