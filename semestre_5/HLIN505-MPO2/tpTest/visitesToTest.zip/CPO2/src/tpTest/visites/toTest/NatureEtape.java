package tpTest.visites.toTest;

public enum NatureEtape {
musee,
visiteMonument,
visiteJardin,
lieuInteretSansVisite;
}
